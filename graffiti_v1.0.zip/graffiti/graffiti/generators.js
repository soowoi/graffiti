function plot(buf,i,j){
	buf[i] |= (0x01 << j) ;
}

function gen_code(block,buf,speed){
	var code='',str = '';
	for (var x = 0; x < 16; x++) {
		var byte = 0;
		for (var y = 0; y < 8; y++) {
			var val = block.getFieldValue('POS_X' + x + '_Y' + y);
			if (val == 'TRUE') {
				byte |= (0x01 << y);
			};
		}
		buf[x] = byte;
	}

	for (var k = 0; k < 16; k++) {
		str += '\\x' + buf[k].toString(16);;
	}

	code += 'ht16k33.show((uint8_t *)"' + str + '");\n';
	code += 'vTaskDelay(' + speed + ' / portTICK_RATE_MS);\n';
	return code;
}


Blockly.JavaScript['graffiti_16x8'] = function(block) {
	var buf = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00];
	var direction = parseInt(block.getFieldValue('direction'));
	var step = parseInt(block.getFieldValue('step'));
	var speed = parseInt(block.getFieldValue('speed'));
	//console.log("direction="+direction+",step="+step+",speed="+speed);

	if( direction == 0 ){ //no animate
		var str = '';
		for (var x = 0; x < 16; x++) {
			var byte = 0;
			for (var y = 0; y < 8; y++) {
				var val = block.getFieldValue('POS_X' + x + '_Y' + y);
				if (val == 'TRUE') {
					byte |= (0x01 << y);
				};
			}
			buf[x] = byte;
		}

		for (var i = 0; i < 16; i++) {
			str += '\\x' + buf[i].toString(16);;
		}
		return 'ht16k33.show((uint8_t *)"' + str + '");\n';
	}
	else if(direction == 1){ //animate right
		var code = '';
		for(var i=0; i< step ; i++){
			for (var y = 0; y < 8; y++) {
				var lastPointValue=false;
				for (var x = 15; x >= 0; x--) {
					if (x != 0) {
						var val = block.getFieldValue('POS_X' + (x - 1) + '_Y' + y);
						if(x == 15){
							lastPointValue=block.getFieldValue('POS_X' + x  + '_Y' + y);
						}
						block.setFieldValue(val, 'POS_X' + x + '_Y' + y);
					} else {
						block.setFieldValue(lastPointValue,'POS_X' + x + '_Y' + y);
					}
				}
			}
			code += gen_code(block,buf,speed);
		} //for step
		return code;
	} //end direction = 1
	else if(direction == 2){ //animate left
		var code ='';
		for(var i=0; i< step ; i++){
			for (var y = 0; y < 8; y++) {
				var lastPointValue=false;
				for (var x = 0; x < 16; x++) {
					if (x != 15) {
						var val = block.getFieldValue('POS_X' + (x + 1) + '_Y' + y);
						if(x == 0){
							lastPointValue=block.getFieldValue('POS_X' + x  + '_Y' + y);
						}
						block.setFieldValue(val, 'POS_X' + x + '_Y' + y);
					} else {
						block.setFieldValue(lastPointValue,'POS_X' + x + '_Y' + y);
					}
				}
			}
			code += gen_code(block,buf,speed);
		} //for step
		return code;
	} //end direction = 2
	else if(direction == 3){ //animate top
		var lastPointValue=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
		var code ='';
		for(var i=0; i< step ; i++){
			for (var y = 7; y >= 0; y--) {
				for (var x = 0; x < 16; x++) {
					if (y != 0) {
						var val = block.getFieldValue('POS_X' + x + '_Y' + (y - 1));
						if(y == 7){
						 	lastPointValue[x] = block.getFieldValue('POS_X' + x  + '_Y' + y);
						}
						block.setFieldValue(val, 'POS_X' + x + '_Y' + y);
					} else {
						block.setFieldValue(lastPointValue[x], 'POS_X' + x + '_Y' + y);
					}
				}
			}
			code += gen_code(block,buf,speed);
		} //for step
		return code;

	}//end direction = 3
	else if(direction == 4){
		var lastPointValue=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
		var code ='';
		for(var i=0; i< step ; i++){
			for (var y = 0; y < 8; y++) {
				for (var x = 0; x < 16; x++) {
					if (y != 7) {
						var val = block.getFieldValue('POS_X' + x + '_Y' + (y + 1));
						if(y == 0){
						 	lastPointValue[x] = block.getFieldValue('POS_X' + x  + '_Y' + y);
						}
						block.setFieldValue(val, 'POS_X' + x + '_Y' + y);
					} else {
						block.setFieldValue(lastPointValue[x], 'POS_X' + x + '_Y' + y);
					}
				}
			}
			code += gen_code(block,buf,speed);
		} //for step
		return code;

	}//end directin = 4

};

