Blockly.Blocks["graffiti_16x8"] = {
	init: function() {
		this.appendDummyInput()
		.appendField(Blockly.Msg.GRAFFITI_16x8_TITLE)
		.appendField("            ")
		.appendField(new Blockly.FieldImage("/icons/shift_left_24px.svg", 24, 24, "*", function(e) {
			for (var y = 0; y < 8; y++) {
				var lastPointValue=false;
				for (var x = 0; x < 16; x++) {
					if (x != 15) {
						var val = e.sourceBlock_.getFieldValue('POS_X' + (x + 1) + '_Y' + y);
						if(x == 0){
							lastPointValue = e.sourceBlock_.getFieldValue('POS_X' + x  + '_Y' + y);
						}
						e.sourceBlock_.setFieldValue(val, 'POS_X' + x + '_Y' + y);
					} else {
						e.sourceBlock_.setFieldValue(lastPointValue, 'POS_X' + x + '_Y' + y);
					}
				}
			}
		}, true))
		.appendField(new Blockly.FieldImage("/icons/shift_right_24px.svg", 24, 24, "*", function(e) {
			for (var y = 0; y < 8; y++) {
				var lastPointValue=false;
				for (var x = 15; x >= 0; x--) {
					if (x != 0) {
						var val = e.sourceBlock_.getFieldValue('POS_X' + (x - 1) + '_Y' + y);
						if(x == 15){
						 	lastPointValue = e.sourceBlock_.getFieldValue('POS_X' + x  + '_Y' + y);
						}
						e.sourceBlock_.setFieldValue(val, 'POS_X' + x + '_Y' + y);
					} else {
						e.sourceBlock_.setFieldValue(lastPointValue,'POS_X' + x + '_Y' + y);
					}
				}
			}
		}, true))
		.appendField(new Blockly.FieldImage("/icons/shift_up_24px.svg", 24, 24, "*", function(e) {
			var lastPointValue=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
			for (var y = 7; y >= 0; y--) {
				for (var x = 0; x < 16; x++) {
					if (y != 0) {
						var val = e.sourceBlock_.getFieldValue('POS_X' + x + '_Y' + (y - 1));
						if(y == 7){
						 	lastPointValue[x] = e.sourceBlock_.getFieldValue('POS_X' + x  + '_Y' + y);
						}
						e.sourceBlock_.setFieldValue(val, 'POS_X' + x + '_Y' + y);
					} else {
						e.sourceBlock_.setFieldValue(lastPointValue[x], 'POS_X' + x + '_Y' + y);
					}
				}
			}
		}, true))
		.appendField(new Blockly.FieldImage("/icons/shift_down_24px.svg", 24, 24, "*", function(e) {
			var lastPointValue=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
			for (var y = 0; y < 8; y++) {
				for (var x = 0; x < 16; x++) {
					if (y != 7) {
						var val = e.sourceBlock_.getFieldValue('POS_X' + x + '_Y' + (y + 1));
						if(y == 0){
						 	lastPointValue[x] = e.sourceBlock_.getFieldValue('POS_X' + x  + '_Y' + y);
						}
						e.sourceBlock_.setFieldValue(val, 'POS_X' + x + '_Y' + y);
					} else {
						e.sourceBlock_.setFieldValue(lastPointValue[x], 'POS_X' + x + '_Y' + y);
					}
				}
			}
		}, true));

		for (var y = 7; y >= 0; y--) {
			var line = this.appendDummyInput();
			for (var x = 0; x < 16; x++) {
				line.appendField(new Blockly.FieldCheckbox('false', null, true), 'POS_X' + x + '_Y' + y);
			}
		
		}
		this.appendDummyInput()
			.appendField(Blockly.Msg.GRAFFITI_16x8_TRANSLATE)
			.appendField(new Blockly.FieldDropdown(
				[
					[Blockly.Msg.GRAFFITI_MOVE_NO,"0"],
					[Blockly.Msg.GRAFFITI_MOVE_RIGHT,"1"], 
					[Blockly.Msg.GRAFFITI_MOVE_LEFT,"2"],
					[Blockly.Msg.GRAFFITI_MOVE_TOP,"3"],
					[Blockly.Msg.GRAFFITI_MOVE_BOTTOM,"4"]
				]) , "direction")
			.appendField(Blockly.Msg.GRAFFITI_STEP)
			.appendField(new Blockly.FieldNumber(), 'step')
			.appendField(Blockly.Msg.GRAFFITI_SPEED)
			.appendField(new Blockly.FieldDropdown([
				["1","1000"], 
				["2","500"], 
				["3","250"], 
				["4","100"], 
				["5","50"], 
				["6","40"], 
				["7","30"], 
			]), "speed");


		this.setPreviousStatement(true);
		this.setNextStatement(true);
		this.setColour("#0080FF");
	}
};


