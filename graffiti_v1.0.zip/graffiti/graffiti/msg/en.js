Blockly.Msg.GRAFFITI_16x8_TITLE = "Graffiti 16x8 Animator";
Blockly.Msg.GRAFFITI_16x8_TRANSLATE = "Translate";

Blockly.Msg.GRAFFITI_STEP = "step";
Blockly.Msg.GRAFFITI_SPEED = "speed";
Blockly.Msg.GRAFFITI_MOVE_NO = "่STOP";
Blockly.Msg.GRAFFITI_MOVE_LEFT = "LEFT";
Blockly.Msg.GRAFFITI_MOVE_RIGHT = "RIGHT";
Blockly.Msg.GRAFFITI_MOVE_TOP = "TOP";
Blockly.Msg.GRAFFITI_MOVE_BOTTOM = "BOTTOM";

Blockly.Msg.GRAFFITI_DRAW = "Draw";
Blockly.Msg.GRAFFITI_FILL = "Fill";
Blockly.Msg.GRAFFITI_WIDTH = "Width";
Blockly.Msg.GRAFFITI_HEIGHT = "Height";

Blockly.Msg.GRAFFITI_RECTANGLE = "Rectangle";
Blockly.Msg.GRAFFITI_LINE = "Line";
Blockly.Msg.GRAFFITI_LINE_COLUMN = "Line Column";
Blockly.Msg.GRAFFITI_LINE_ROW = "Line Row";
Blockly.Msg.GRAFFITI_TRANSLATE_ROW = "Translate Line Row";
Blockly.Msg.GRAFFITI_TRANSLATE_COLUMN = "Translate Line Column";

Blockly.Msg.GRAFFITI_EFFECT = "Effect";
Blockly.Msg.GRAFFITI_DIRECTION = "Direction";
Blockly.Msg.GRAFFITI_DIRECTION_IN = "IN";
Blockly.Msg.GRAFFITI_DIRECTION_OUT = "OUT";
Blockly.Msg.GRAFFITI_DELAY = "Delay";
Blockly.Msg.GRAFFITI_MILLIS = "Milli second";

Blockly.Msg.GRAFFITI_POINT1 = "Point1";
Blockly.Msg.GRAFFITI_POINT2 = "Point2";
Blockly.Msg.GRAFFITI_TO = "To";
