Blockly.Msg.GRAFFITI_16x8_TITLE = "กราฟิตี้ 16x8 แอนิเมเตอร์";
Blockly.Msg.GRAFFITI_16x8_TRANSLATE = "เลื่อนไปด้าน";

Blockly.Msg.GRAFFITI_STEP = "จุด";
Blockly.Msg.GRAFFITI_SPEED = "ความเร็ว";
Blockly.Msg.GRAFFITI_MOVE_NO = "หยุด";
Blockly.Msg.GRAFFITI_MOVE_LEFT = "ซ้าย";
Blockly.Msg.GRAFFITI_MOVE_RIGHT = "ขวา";
Blockly.Msg.GRAFFITI_MOVE_TOP = "บน";
Blockly.Msg.GRAFFITI_MOVE_BOTTOM = "ล่าง";

Blockly.Msg.GRAFFITI_DRAW = "วาด";
Blockly.Msg.GRAFFITI_FILL = "ระบาย";
Blockly.Msg.GRAFFITI_WIDTH = "ยาว";
Blockly.Msg.GRAFFITI_HEIGHT = "สูง";

Blockly.Msg.GRAFFITI_RECTANGLE = "สี่เหลี่ยม";
Blockly.Msg.GRAFFITI_LINE = "วาดเส้น"; 
Blockly.Msg.GRAFFITI_LINE_COLUMN = "เส้นคอลัมน์";
Blockly.Msg.GRAFFITI_LINE_ROW = "เส้นแถว";
Blockly.Msg.GRAFFITI_TRANSLATE_ROW = "เลื่อนเส้นแถว";
Blockly.Msg.GRAFFITI_TRANSLATE_COLUMN = "เลื่อนเส้นคอลัมน์";

Blockly.Msg.GRAFFITI_EFFECT = "เอฟเฟคส์";
Blockly.Msg.GRAFFITI_DIRECTION = "ทิศทาง";
Blockly.Msg.GRAFFITI_DIRECTION_IN = "เข้าใน";
Blockly.Msg.GRAFFITI_DIRECTION_OUT = "ออกนอก";
Blockly.Msg.GRAFFITI_DELAY = "หน่วงเวลา";
Blockly.Msg.GRAFFITI_MILLIS = "มิลลิวินาที";

Blockly.Msg.GRAFFITI_POINT1 = "จุดที่หนึ่ง";
Blockly.Msg.GRAFFITI_POINT2 = "จุดที่สอง";
Blockly.Msg.GRAFFITI_TO = "ไปยัง";